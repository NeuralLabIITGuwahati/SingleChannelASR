% Main script with example.

% Load dataset
load subject_3.mat;
fs = EEG.srate;

% specify channel number of interest
% 1 for Fp1/FPz or 2 for Fp2
channelNumber = 1; 

signal = double(EEG.data(channelNumber,:)); % taking single channel from data.

signalClean = single_channel_ASR(signal,fs); % generates clean signal

% Count of eye blinks before and after ASR
% First 4 seconds are excluded for subjects 1-3
[blinks_beforeASR,blinks_afterASR] = eye_blink_count(signal(1,2001:end),signalClean(1,2001:end),fs); 
