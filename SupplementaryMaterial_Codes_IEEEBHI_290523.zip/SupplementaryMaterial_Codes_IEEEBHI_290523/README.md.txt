README

"EVALUATION OF SINGLE CHANNEL ARTIFACT SUBSPACE RECONSTRUCTION FOR ELECTROENCEPHALOGRAM"

PREREQUISITES:
•	Statistics and Machine Learning Toolbox
•	Signal Processing Toolbox
•	All the datasets must be in the same folder as the .m and .p files.

Artifact Subspace Reconstruction (ASR) was developed by C.A.Kothe and T.P. Jung in 2016 [1]. The codes for ASR are sourced from the clean_rawdata plugin of EEGLAB [2]. The codes were used to perform ASR on the multichannel EEG matrix created from single channel EEG signal.

.p FILES:
•	single_channel_ASR: To create multichannel dataset from single channel, perform ASR and produce clean single channel signal.
•	eye_blink_count: To count eye blinks of original signal and ASR-cleaned signal using amplitude threshold method.

.m FILES:
•	Main.m - Main script with example.
•	asr_calibrate [2] - Calibration function for the ASR method.
•	asr_process [2] - Processing function for the ASR method.
•	fit_eeg_distribution [2] - Estimate mean and standard deviation of clean EEG from contaminated data.
•	block_geometric_median [2] - Calculate a blockwise geometric median.
•	geometric_median [2] - Calculate the geometric median for a set of observations.
•	hlp_memfree [2] - Get the amount of free physical memory in bytes.
•	moving_average [3] - Run a moving-average filter along the second dimension of the data.

.mat FILES:
Subjects 1-3 were tasked with keeping eyes closed for 5 minutes followed by eyes open for 5 minutes. Subject 1 and 2 were male while subject 3 was a female.
Subject 4 is the EEGLAB sample data named eeglab_data.set in EEGLAB.
•	subject_1 – 24 channels; Sampling rate: 500 Hz.
•	subject_2 – 24 channels; Sampling rate: 500 Hz.
•	subject_3 – 24 channels; Sampling rate: 500 Hz.
•	subject_4 – 32 channels; Sampling rate: 128 Hz.
Subject 3 is provided as sample for running the codes here.


HOW TO RUN THE CODE:
•	Download all MATLAB .m, .p (Codes) and .mat (Data) in the same folder.
•	The main code with example is in Main.m which should be opened.
•	Load the desired dataset in line 4.
•	Specify channel number in line 9. 
	o	For subjects 1-3:
			Fp1: channelNumber = 1;
			Fp2: channelNumber = 2;
	o	For subject 4:
			FPz: channelNumber = 1;
•	Run Main.m. 
•	Desired outputs:
	o	signalClean: single channel ASR-cleaned signal
	o	blinks_beforeASR: No. of eye blinks before ASR.
	o	blinks_afterASR: No. of eye blinks after ASR.

REFERENCES:
[1] Kothe, C. A. E. & Jung, T. P., “Artifact removal techniques with signal reconstruction,” U.S. 20 160 113 587 A1, 2016
[2] A. Delorme and S. Makeig, “EEGLAB: an open source toolbox for analysis of single-trial EEG dynamics including independent component analysis,” J. Neurosci. Methods, vol. 134, no. 1, pp. 9–21, Mar. 2004, doi: 10.1016/j.jneumeth.2003.10.009.
[3] Kothe, C. A. E., Fast moving average (https://www.mathworks.com/matlabcentral/fileexchange/34567-fast-moving-average), MATLAB Central File Exchange, 2023
